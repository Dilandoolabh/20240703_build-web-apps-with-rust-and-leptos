---
name: "\U0001F680 Feature request"
about: Suggest a new feature to be implemented.
title: ""
labels: enhancement
assignees: ""
---

<!--
Thank you for adding a feature request to ryu-js! Please fill the following template. Feel free to add or remove sections as needed.
-->

**Feature description**
<!-- Explain the feature that you'd like to see implemented. -->

