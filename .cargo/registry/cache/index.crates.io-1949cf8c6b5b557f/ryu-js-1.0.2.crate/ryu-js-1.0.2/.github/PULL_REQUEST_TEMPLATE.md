<!---
Thank you for contributing to ryu-js! Please fill out the template below, and remove or add any information as you feel necessary.
--->

This Pull Request fixes/closes #{issue_num}.

It changes the following:

-
-
-
