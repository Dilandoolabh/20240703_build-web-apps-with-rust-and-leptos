export const foo1 = 1;
export var foo2: number = "abc";
export enum Foo3 {
    A = "foo",
    B = "bar",
}
