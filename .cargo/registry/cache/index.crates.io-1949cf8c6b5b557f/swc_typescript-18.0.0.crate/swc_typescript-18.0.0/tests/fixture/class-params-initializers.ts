export class Object {
    constructor(
        values: {},
        {
            a,
            b,
        }: {
            a?: A;
            b?: B;
        } = {}
    ) {}

    method(
        values: {},
        {
            a,
            b,
        }: {
            a?: A;
            b?: B;
        } = {},
        value = 1
    ) {}
}
