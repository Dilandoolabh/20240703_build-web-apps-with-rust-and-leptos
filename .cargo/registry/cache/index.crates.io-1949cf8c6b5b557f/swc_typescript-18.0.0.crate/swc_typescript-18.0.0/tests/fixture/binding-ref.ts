export const ssrUtils = { createComponentInstance: 1 };
const { createComponentInstance } = ssrUtils;
export function createComponentInstance(): void {}
