type A = number;
type B = A | string;
export function exp1(): void {}

var a = 1;
var b: typeof a = 2;
export function exp2(): void {}

export {};
