/**
 * Sample JSDoc that I wish was in the swc.transform output
 * @param a - string param
 * @param b - number param
 * @returns - object with a and b
 */
function sampleFunc(a: string, b: number): void {}
