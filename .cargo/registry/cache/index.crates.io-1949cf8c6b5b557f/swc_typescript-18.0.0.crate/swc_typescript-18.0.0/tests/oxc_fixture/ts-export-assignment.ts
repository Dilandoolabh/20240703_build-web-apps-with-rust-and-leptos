const Res = 0;

export = function Foo(): typeof Res {
  return Res;
}