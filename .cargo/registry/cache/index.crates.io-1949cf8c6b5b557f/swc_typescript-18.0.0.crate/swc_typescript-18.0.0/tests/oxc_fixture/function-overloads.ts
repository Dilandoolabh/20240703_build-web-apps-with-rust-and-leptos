function a(a: number): number;
function a(a: string): string;
function a(a: any): any {}


function b(a: number): number {};
function b(a: string): string {};
