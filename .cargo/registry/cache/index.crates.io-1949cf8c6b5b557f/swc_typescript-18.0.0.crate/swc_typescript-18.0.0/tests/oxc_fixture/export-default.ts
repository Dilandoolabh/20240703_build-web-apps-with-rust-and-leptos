const defaultDelimitersClose = new Uint8Array([125, 125])

export default class Tokenizer {
  public delimiterClose: Uint8Array = defaultDelimitersClose
}

