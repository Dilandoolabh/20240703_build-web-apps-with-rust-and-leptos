#![allow(clippy::boxed_local)]

pub mod diagnostic;
pub mod fast_dts;
