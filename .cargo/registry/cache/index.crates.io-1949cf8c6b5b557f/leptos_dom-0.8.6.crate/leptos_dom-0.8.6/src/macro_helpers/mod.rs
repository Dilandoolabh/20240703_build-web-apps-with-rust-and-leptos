#[cfg(feature = "trace-component-props")]
#[doc(hidden)]
pub mod tracing_property;
