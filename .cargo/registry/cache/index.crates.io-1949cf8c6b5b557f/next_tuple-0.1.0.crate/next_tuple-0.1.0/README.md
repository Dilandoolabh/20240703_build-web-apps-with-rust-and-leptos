Allows extending a tuple, or creating a new tuple, by adding the next value.
