# swc_transform_common

Common utilities for the author of a swc transform.
