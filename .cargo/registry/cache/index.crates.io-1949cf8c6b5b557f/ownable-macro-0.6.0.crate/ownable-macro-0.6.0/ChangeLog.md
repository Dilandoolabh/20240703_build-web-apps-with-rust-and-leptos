# Changelog for ownable-macro

## 0.6.0 -- 2023-05-06

* Support to not generate functions
* Support generics
* Support const generics
* Support references

## 0.5.0 -- 2023-04-12

* Initial release
