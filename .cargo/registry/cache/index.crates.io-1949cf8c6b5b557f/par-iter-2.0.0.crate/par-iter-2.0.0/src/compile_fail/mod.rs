// These modules contain `compile_fail` doc tests.
mod cannot_collect_filtermap_data;
mod cannot_zip_filtered_data;
mod cell_par_iter;
mod must_use;
mod no_send_par_iter;
mod rc_par_iter;
