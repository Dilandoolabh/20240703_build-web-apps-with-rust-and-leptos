# simple-git

The simple git interface for gix suitable for async context (with tokio)
