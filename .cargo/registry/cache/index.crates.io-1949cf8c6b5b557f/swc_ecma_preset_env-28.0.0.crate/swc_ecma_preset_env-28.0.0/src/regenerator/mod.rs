pub(super) fn is_required<T>(_: &T) -> bool {
    false
}
