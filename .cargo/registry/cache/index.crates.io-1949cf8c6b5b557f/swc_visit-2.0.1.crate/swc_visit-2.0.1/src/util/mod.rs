//! Some utilities for generated visitors.
pub mod map;
pub mod move_map;
