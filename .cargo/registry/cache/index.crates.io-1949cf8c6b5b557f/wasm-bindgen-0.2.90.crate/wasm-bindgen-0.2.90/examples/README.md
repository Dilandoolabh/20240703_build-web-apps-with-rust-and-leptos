# Examples

This directory contains a number of Cargo projects that are all examples of how
to use `wasm-bindgen` in various contexts. More documentation can be [found
online][dox]

[dox]: https://rustwasm.github.io/docs/wasm-bindgen/examples/index.html
