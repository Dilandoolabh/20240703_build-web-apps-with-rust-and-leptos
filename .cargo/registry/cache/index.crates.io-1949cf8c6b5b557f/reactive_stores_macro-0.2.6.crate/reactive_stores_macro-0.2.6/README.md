This crate provides macro that are helpful or required when using the `reactive_stores` crate.
