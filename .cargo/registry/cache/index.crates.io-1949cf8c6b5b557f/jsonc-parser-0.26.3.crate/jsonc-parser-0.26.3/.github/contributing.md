# Contributing

Todo...

## Benchmarks

See [Benchmarks](https://dprint.github.io/jsonc-parser/dev/bench/)
