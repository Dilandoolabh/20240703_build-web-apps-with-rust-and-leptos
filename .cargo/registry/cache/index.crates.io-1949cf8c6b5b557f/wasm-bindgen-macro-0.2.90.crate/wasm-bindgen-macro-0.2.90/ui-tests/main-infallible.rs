use std::convert::Infallible;
use wasm_bindgen::prelude::*;

#[wasm_bindgen(main)]
fn main() -> Infallible {
    unimplemented!()
}

#[wasm_bindgen(main)]
fn fail() {}
