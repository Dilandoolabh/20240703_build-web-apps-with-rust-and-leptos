use st_map::StaticMap;

#[derive(StaticMap)]
pub struct Record {
    pub a: String,
    pub b: String,
    pub c: String,
}
