use is_macro::Is;

#[derive(Debug, Is)]
pub enum Enum {
    B(usize),
}
