# is-macro

See the [documentation](https://docs.rs/is-macro) for more information.

## License

Apache 2.0
