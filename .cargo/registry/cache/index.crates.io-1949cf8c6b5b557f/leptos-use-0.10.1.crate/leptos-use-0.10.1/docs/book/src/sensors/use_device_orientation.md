# use_device_orientation

<!-- cmdrun python3 ../extract_doc_comment.py use_device_orientation  -->
