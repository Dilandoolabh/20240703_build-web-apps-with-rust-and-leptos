# use_element_size

<!-- cmdrun python3 ../extract_doc_comment.py use_element_size -->
