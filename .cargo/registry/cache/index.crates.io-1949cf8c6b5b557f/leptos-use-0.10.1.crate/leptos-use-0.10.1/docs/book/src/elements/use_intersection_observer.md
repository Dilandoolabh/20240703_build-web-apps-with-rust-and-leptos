# use_intersection_observer

<!-- cmdrun python3 ../extract_doc_comment.py use_intersection_observer -->
