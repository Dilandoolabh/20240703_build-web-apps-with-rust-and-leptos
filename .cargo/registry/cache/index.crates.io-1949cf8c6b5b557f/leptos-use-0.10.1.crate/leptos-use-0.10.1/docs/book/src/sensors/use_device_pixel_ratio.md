# use_device_pixel_ratio

<!-- cmdrun python3 ../extract_doc_comment.py use_device_pixel_ratio  -->
