# is_ok

<!-- cmdrun python3 ../extract_doc_comment.py is_ok  -->
