# is_none

<!-- cmdrun python3 ../extract_doc_comment.py is_none  -->
