# is_some

<!-- cmdrun python3 ../extract_doc_comment.py is_some  -->
