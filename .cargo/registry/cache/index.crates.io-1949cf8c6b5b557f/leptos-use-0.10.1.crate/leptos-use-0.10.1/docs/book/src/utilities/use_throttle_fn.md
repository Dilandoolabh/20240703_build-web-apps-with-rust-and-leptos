# use_throttle_fn

<!-- cmdrun python3 ../extract_doc_comment.py use_throttle_fn -->
