# use_intl_number_format

<!-- cmdrun python3 ../extract_doc_comment.py use_intl_number_format  -->
