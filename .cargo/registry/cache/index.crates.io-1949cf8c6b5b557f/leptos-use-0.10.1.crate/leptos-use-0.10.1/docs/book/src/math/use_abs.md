# use_abs

<!-- cmdrun python3 ../extract_doc_comment.py math/use_abs math -->
