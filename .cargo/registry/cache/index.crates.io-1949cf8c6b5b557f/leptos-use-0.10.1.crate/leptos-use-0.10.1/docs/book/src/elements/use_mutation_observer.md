# use_mutation_observer

<!-- cmdrun python3 ../extract_doc_comment.py use_mutation_observer -->
