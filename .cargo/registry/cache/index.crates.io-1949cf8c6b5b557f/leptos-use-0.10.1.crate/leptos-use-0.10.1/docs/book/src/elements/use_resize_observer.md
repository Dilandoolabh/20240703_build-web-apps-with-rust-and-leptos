# use_resize_observer

<!-- cmdrun python3 ../extract_doc_comment.py use_resize_observer -->
