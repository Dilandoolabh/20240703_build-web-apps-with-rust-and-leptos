#!/usr/bin/env bash

ffizer apply --source template --destination .