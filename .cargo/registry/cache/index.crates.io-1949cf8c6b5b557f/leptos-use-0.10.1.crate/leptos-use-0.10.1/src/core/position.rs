#[derive(Copy, Clone, Default, Debug)]
pub struct Position {
    pub x: f64,
    pub y: f64,
}
