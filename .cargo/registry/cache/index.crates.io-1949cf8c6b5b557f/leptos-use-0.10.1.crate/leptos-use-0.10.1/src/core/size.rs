#[derive(Copy, Clone, Default, PartialEq)]
pub struct Size {
    pub width: f64,
    pub height: f64,
}
