pub mod global_defs;
pub mod mangle_names;
pub mod mangle_props;
pub mod merge_exports;
pub mod postcompress;
