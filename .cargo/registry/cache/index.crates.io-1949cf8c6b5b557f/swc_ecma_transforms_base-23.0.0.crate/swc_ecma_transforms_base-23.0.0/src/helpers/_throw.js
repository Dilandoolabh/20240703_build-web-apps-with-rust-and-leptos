function _throw(e) {
    throw e;
}
