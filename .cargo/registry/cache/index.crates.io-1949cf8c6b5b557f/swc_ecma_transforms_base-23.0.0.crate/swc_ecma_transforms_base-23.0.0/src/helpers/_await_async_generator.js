function _await_async_generator(value) {
    return new _overload_yield(value, /* kind: await */ 0);
}
