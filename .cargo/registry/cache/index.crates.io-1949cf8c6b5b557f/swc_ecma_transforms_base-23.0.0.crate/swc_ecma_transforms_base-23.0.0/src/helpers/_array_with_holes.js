function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
