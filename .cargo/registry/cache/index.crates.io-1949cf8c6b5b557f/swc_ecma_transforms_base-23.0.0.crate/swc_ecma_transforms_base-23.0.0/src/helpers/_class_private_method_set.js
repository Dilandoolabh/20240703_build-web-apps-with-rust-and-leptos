function _class_private_method_set() {
    throw new TypeError("attempted to reassign private method");
}
