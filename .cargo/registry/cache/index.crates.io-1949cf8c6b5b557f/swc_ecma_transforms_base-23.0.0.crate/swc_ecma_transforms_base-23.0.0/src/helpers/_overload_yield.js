function _overload_yield(value, /** 0: await 1: delegate */ kind) {
    this.v = value;
    this.k = kind;
}
