function _await_value(value) {
    this.wrapped = value;
}
