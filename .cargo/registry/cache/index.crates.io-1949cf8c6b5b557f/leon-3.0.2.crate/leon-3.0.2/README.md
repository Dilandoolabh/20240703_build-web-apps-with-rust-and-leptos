# leon

Dead-simple string templating.

Check [here](https://docs.rs/leon) for latest documentation.
