/// represents key value storage of defined values
pub type TemplateValues = HashMap<String, toml::Value>;
