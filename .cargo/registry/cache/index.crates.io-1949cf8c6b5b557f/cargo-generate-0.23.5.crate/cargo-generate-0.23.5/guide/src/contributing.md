# Contributing

Unless you explicitly state otherwise, any contribution intentionally
submitted for inclusion in the work by you, as defined in the Apache-2.0
license, shall be dual licensed as noted in [License](license.md), without any additional terms or
conditions.
If you want to contribute to `cargo-generate`, please see [CONTRIBUTING.md].

[CONTRIBUTING.md]: https://github.com/cargo-generate/cargo-generate/blob/6085896e7025bdbd5690a8cb2b3d4259cf9f825f/CONTRIBUTING.md
