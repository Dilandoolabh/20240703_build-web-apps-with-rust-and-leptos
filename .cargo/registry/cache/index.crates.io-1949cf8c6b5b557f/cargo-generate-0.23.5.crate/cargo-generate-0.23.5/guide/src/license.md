# License

Licensed, at your option, under either of the following licences:

* Apache License, Version 2.0, ([LICENSE-APACHE] or [apache.org/licenses/LICENSE-2.0])
* MIT license ([LICENSE-MIT] or [opensource.org/licenses/MIT])

[LICENSE-APACHE]: https://github.com/cargo-generate/cargo-generate/blob/main/LICENSE-APACHE
[apache.org/licenses/LICENSE-2.0]: https://www.apache.org/licenses/LICENSE-2.0
[LICENSE-MIT]: https://github.com/cargo-generate/cargo-generate/blob/main/LICENSE-MIT
[opensource.org/licenses/MIT]: https://opensource.org/licenses/MIT
