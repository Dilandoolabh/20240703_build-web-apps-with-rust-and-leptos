# Expanded template

This is the `README.md` for the expanded template.
