# This file should not be kept in the final generated project

The rhai hook `remove-unwanted.rhai` takes care of removing this file from the final generated project.
