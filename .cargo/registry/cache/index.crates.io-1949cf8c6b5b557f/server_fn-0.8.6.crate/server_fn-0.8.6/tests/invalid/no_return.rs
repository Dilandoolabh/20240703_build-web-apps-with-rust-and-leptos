use server_fn_macro_default::server;

#[server]
pub async fn no_return() {}

fn main() {}