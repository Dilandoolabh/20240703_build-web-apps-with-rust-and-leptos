# static-map-macro

Derive macro for [`st-map`](https://docs.rs/st-map/).
