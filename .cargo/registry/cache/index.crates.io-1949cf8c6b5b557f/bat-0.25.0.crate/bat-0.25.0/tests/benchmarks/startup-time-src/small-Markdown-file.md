# Keep this file small, we want to measure bat startup time, not speed of Markdown highlighting!

The Markdown syntax definition references ~18 other syntaxes, so without lazy-loading, it will be slow to load.
