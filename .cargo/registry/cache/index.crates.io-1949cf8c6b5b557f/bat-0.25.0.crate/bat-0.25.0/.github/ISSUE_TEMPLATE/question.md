---
name: Question
about: Ask a question about 'bat'.
title: ''
labels: question
assignees: ''

---

<!-- Using a normal ticket is still fine, but feel free to ask your
questions about bat on https://github.com/sharkdp/bat/discussions instead. -->
