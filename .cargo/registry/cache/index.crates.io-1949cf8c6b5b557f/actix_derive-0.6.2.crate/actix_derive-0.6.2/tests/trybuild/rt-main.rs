#[actix::main]
async fn main() {
    async { 1 }.await;
}
