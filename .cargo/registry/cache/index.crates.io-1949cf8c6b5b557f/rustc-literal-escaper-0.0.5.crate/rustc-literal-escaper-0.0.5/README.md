# rustc-literal-escaper

Provides code to unescape string literals. It is used by `rustc_lexer` and `proc_macro`.
