This crate is reserved to avoid confusion with `cargo-binstall`.

Please see <https://github.com/cargo-bins/cargo-binstall>.
