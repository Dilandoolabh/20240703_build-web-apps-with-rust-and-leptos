compile_error!("This isn't a real crate! You probably want cargo-binstall.\nSee <https://github.com/cargo-bins/cargo-binstall>");
fn main() {}
