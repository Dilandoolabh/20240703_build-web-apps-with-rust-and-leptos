# Changelog for ownable

## 0.6.2 -- 2024-02-04

* Support arrays

## 0.6.1 -- 2023-09-20

* Support tuples

## 0.6.0 -- 2023-05-06

* Support to not generate functions
* Support generics
* Support const generics
* Support references

## 0.5.0 -- 2023-04-12

* Initial release
