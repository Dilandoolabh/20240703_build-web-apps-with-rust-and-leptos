//! Examples for the `flexi_logger` initialization.
#![doc = include_str!("code_examples.md")]
