Utilities for working with enumerated types that contain one of `2..n` other types.
