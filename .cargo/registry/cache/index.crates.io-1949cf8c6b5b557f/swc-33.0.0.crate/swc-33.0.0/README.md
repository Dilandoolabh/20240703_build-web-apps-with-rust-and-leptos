## Testing

### `tests/exec`

All files named `exec.js` or `exec.ts` will be executed, and the test system will ensure that original source code and transpiled source code print the same output to the console.

You can use `./scripts/check-issues.sh` to automatically unignore fixed tests.
