use swc_common::*;

pub struct Struct {}

#[derive(FromVariant)]
pub enum Enum {}
