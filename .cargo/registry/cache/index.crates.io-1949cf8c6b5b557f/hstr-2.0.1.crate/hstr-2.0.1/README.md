# hstr

A high-performance string interning library for Rust. This crate is intended for the compilers or build tools like a bundler, written in Rust.

See the [documentation](https://docs.rs/hstr) for more information.

## License

Apache 2.0
