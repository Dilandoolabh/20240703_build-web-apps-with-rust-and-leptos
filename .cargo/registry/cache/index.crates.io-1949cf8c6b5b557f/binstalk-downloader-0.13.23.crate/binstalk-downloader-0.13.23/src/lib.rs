#![cfg_attr(docsrs, feature(doc_auto_cfg))]

pub use bytes;
pub mod download;
pub mod remote;
mod utils;
