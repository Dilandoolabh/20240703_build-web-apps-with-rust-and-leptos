wasm_bindgen_test::wasm_bindgen_test_configure!(run_in_browser);

mod common;
